<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\wamp64\www\Test\public/../application/index\view\Index\login.html";i:1545896052;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>登入页面</title>

    <!-- Bootstrap core CSS -->
    <link href="/Test/public/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/Test/public/css/login.css" rel="stylesheet">

    <script src="/Test/public/js/jquery-2.1.0.min.js"></script>
    <script src="/Test/public/js/bootstrap.js"></script>

</head>

<body>

<div class="container">

    <form class="form-signin" action="/Test/public/index/Index/login" method="post">
        <div class="text-center">
            <h2 class="form-signin-heading">登录</h2>
        </div>
		<div class="col-sm-8" align="center">
			<span style="color: red;"><?php echo (isset($info) && ($info !== '')?$info:''); ?></span>
		</div>				
        <label for="inputText" class="sr-only">用户名</label>
        <input type="text" id="inputText" value="" name="username" class="form-control" placeholder="用户名" required autofocus>
        <label for="inputPassword" class="sr-only">密码</label>
        <input type="password" id="inputPassword" value="" name="password" class="form-control" placeholder="密码" required>
        <label for="inputText" class="sr-only">用户类型</label>
        <input type="text" id="inputText" value="" name="usertype" class="form-control" placeholder="用户类型" required>
        
		<div class="checkbox">
            <label>
                <input type="checkbox" name="remember" checked value="rememberMe"> 记住用户名和密码
            </label>
        </div>
        <button class="btn btn-lg btn-info btn-block" type="submit">登入</button>
        <button class="btn btn-lg btn-primary btn-block" id="register" onclick="registerAdmin()" type="button">注册</button>
    </form>

</div> <!-- /container -->
</body>
<script>
    function registerAdmin() {
        location.href = "index/Register/register";
    }
</script>
</html>
<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"C:\wamp64\www\Test\public/../application/index\view\books\add.html";i:1546411890;}*/ ?>
<!DOCTYPE html>
<!-- 网页使用的语言 -->
<html>
<head>
    
    <title>添加用户</title>

    <!-- 1. 导入CSS的全局样式 -->
    <link href="/Test/public/css/bootstrap.min.css" rel="stylesheet">
    <!-- 2. jQuery导入，建议使用1.9以上的版本 -->
    <script src="/Test/public/js/jquery-2.1.0.min.js"></script>
    <!-- 3. 导入bootstrap的js文件 -->
    <script src="/Test/public/js/bootstrap.min.js"></script>
</head>
<body>
	
<div class="container text-left" style="width: 450px;">
    <center><h3>添加图书信息</h3></center>
    <form action="/Test/public/index/Books/addbooks" method="post" class="form-horizontal">       
        <div class="form-group">
           <label class="col-lg-2 control-label" for="ISBN">ISBN：</label>
           <div class="col-lg-8">
               <input type="text" class="form-control" id="ISBN" name="ISBN" placeholder="请输入ISBN">
           </div>
        </div>
        
				<div class="form-group">
            <label for="leibie" class="col-lg-2 control-label">类别：</label>
            <div class="col-lg-8">
                <select name="TypeID" class="form-control" id="TypeID">
                    <option value="1">数学</option>
                    <option value="2">哲学</option>
                    <option value="3">经济</option>
										<option value="4">计算机</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="Name" class="control-label col-lg-2">书名：</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="Name" name="Name" placeholder="请输入书名">
            </div>
        </div>

        <div class="form-group">
            <label for="Press" class="control-label col-lg-2">出版社：</label>
           <div class="col-lg-8">
               <input type="text" class="form-control" id="Press"  name="Press" placeholder="请输入出版社名称"/>
           </div>
        </div>

        <div class="form-group">
            <label for="Date" class="col-lg-2 control-label">出版日期：</label>
           <div class="col-lg-8">
               <input type="date" class="form-control" id="Date" name="Date" placeholder="请输入出版日期"/>
           </div>
        </div>
				
				<div class="form-group">
            <label for="Author" class="col-lg-2 control-label">作者：</label>
           <div class="col-lg-8">
               <input type="text" class="form-control" id="Author" name="Author" placeholder="请输入作者名称"/>
           </div>
        </div>
				
				<div class="form-group">
						<label for="Price" class="col-lg-2 control-label">价格：</label>
					<div class="col-lg-8">
							<input type="text" class="form-control" id="Price" name="Price" placeholder="请输入图书价格"/>
					</div>
				</div>
				
        <div class="form-group" style="text-align: center">
            <input class="btn btn-primary" type="submit" value="提交" />
            <input class="btn btn-default" type="reset" value="重置" />
            <input class="btn btn-default" onclick="backToPrevious()" type="button" value="返回"/>
        </div>
    </form>
</div>
</body>
<script>
    function backToPrevious() {
        history.go(-1);
        // location.href = document.referrer;
    }
</script>
</html>
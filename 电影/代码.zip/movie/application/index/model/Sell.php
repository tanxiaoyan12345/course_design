<?php
namespace app\index\model;

use think\Model;

class Sell extends Model
{
}
?>